const router = require('express').Router();
const { pelanggan } = require('../controllers');

// GET localhost:8080/karyawan => Ambil data semua karyawan
router.get('/', pelanggan.getDatapelanggan);

// // POST localhost:8080/pelanggan/add => Tambah data pelanggan ke database
router.post('/add', pelanggan.addDatapelanggan);

// // POST localhost:8080/pelanggan/2 => Edit data pelanggan
router.put('/edit/:id', pelanggan.editDatapelanggan);

// // POST localhost:8080/pelanggan/delete => Delete data pelanggan
router.delete('/delete/:id', pelanggan.deleteDatapelanggan);

module.exports = router;