const router = require('express').Router();
const { faktur_penjualan } = require('../controllers');

// GET localhost:8080/karyawan => Ambil data semua karyawan
router.get('/', faktur_penjualan.getDatafaktur_penjualan);

// // POST localhost:8080/faktur_penjualan/add => Tambah data faktur_penjualan ke database
router.post('/add', faktur_penjualan.addDatafaktur_penjualan);

// // POST localhost:8080/faktur_penjualan/2 => Edit data faktur_penjualan
router.put('/edit/:id', faktur_penjualan.editDatafaktur_penjualan);

// // POST localhost:8080/faktur_penjualan/delete => Delete data faktur_penjualan
router.delete('/delete/:id', faktur_penjualan.deleteDatafaktur_penjualan);

module.exports = router;