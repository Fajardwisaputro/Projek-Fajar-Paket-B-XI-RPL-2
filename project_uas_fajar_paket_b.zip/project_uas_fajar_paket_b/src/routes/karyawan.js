const router = require('express').Router();
const { karyawan } = require('../controllers');

// GET localhost:8080/karyawan => Ambil data semua karyawan
router.get('/', karyawan.getDatakaryawan);

// // POST localhost:8080/karyawan/add => Tambah data karyawan ke database
router.post('/add', karyawan.addDatakaryawan);

// // POST localhost:8080/karyawan/2 => Edit data karyawan
router.put('/edit/:id', karyawan.editDatakaryawan);

// // POST localhost:8080/karyawan/delete => Delete data karyawan
router.delete('/delete/:id', karyawan.deleteDatakaryawan);

module.exports = router;