const router = require('express').Router();
const { obat } = require('../controllers');

// GET localhost:8080/karyawan => Ambil data semua karyawan
router.get('/', obat.getDataobat);

// // POST localhost:8080/obat/add => Tambah data obat ke database
router.post('/add', obat.addDataobat);

// // POST localhost:8080/obat/2 => Edit data obat
router.put('/edit/:id', obat.editDataobat);

// // POST localhost:8080/obat/delete => Delete data obat
router.delete('/delete/:id', obat.deleteDataobat);

module.exports = router;