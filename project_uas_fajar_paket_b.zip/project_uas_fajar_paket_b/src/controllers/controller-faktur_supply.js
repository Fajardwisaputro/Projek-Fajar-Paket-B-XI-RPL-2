const config = require('../configs/database');
const mysql = require('mysql');
const connection = mysql.createConnection(config);
connection.connect();

// menampilkan semua data
const getDatafaktur_supply = async (req, res) => {
    const data = await new Promise((resolve, reject) => {
        connection.query('SELECT * FROM faktur_supply', function (error, rows) {
            if (rows) {
                resolve(rows)
            } else {
                reject([]);
            }
        })
    });

    if (data) {
        res.send({
            success: true,
            message: 'Berhasil ambil data!',
            data: data
        });
    } else {
        req.send({
            success: false,
            message: 'Gagal mengambil data!',
        });
    }
}

// menambahkan data 
const addDatafaktur_supply = async (req, res) => {
    let data = {            
        tanggal: req.body.tanggal,
        id_karyawan: req.body.id_karyawan,
        id_supplier: req.body.id_supplier,
        id_obat: req.body.id_obat,
        jumlah_obat: req.body.jumlah_obat,
        total: req.body.total,
        pajak: req.body.pajak,
        total_bayar: req.body.total_bayar
        
    }
    const result = await new Promise((resolve, reject) => {
        connection.query('INSERT INTO faktur_supply SET ?', [data], function (error, rows) {
            if (rows) {
                resolve (true);
            } else  {
                reject (false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil x data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal menambahkan data!',
        })
    }
}

//mengubah data
const editDatafaktur_supply = async (req, res) => {
    let id = req.params.id;
    let dataedit = {
        tanggal: req.body.tanggal,
        id_karyawan: req.body.id_karyawan,
        id_supplier: req.body.id_supplier,
        id_obat: req.body.id_obat,
        jumlah_obat: req.body.jumlah_obat,
        total: req.body.total,
        pajak: req.body.pajak,
        total_bayar: req.body.total_bayar
    }

    const result = await new Promise ((resolve, reject) => {
        connection.query('UPDATE faktur_supply SET ? WHERE id = ?;', [dataedit, id], function (error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil edit data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal edit data!',
        });
    }
}

// menghapus data
const deleteDatafaktur_supply = async (req, res) => {
    let id = req.params.id;

    const result = await new Promise((resolve, reject) => {
        connection.query('DELETE FROM faktur_supply WHERE id = ?;', [id], function (error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil hapus data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal menghapus data!'
        });
    }
}

module.exports = {
    getDatafaktur_supply,
    addDatafaktur_supply,
    editDatafaktur_supply,
    deleteDatafaktur_supply
}