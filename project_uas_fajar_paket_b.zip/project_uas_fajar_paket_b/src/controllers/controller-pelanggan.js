const config = require('../configs/database');
const mysql = require('mysql');
const connection = mysql.createConnection(config);
connection.connect();

// menampilkan semua data
const getDatapelanggan = async (req, res) => {
    const data = await new Promise((resolve, reject) => {
        connection.query('SELECT * FROM pelanggan', function (error, rows) {
            if (rows) {
                resolve(rows)
            } else {
                reject([]);
            }
        })
    });

    if (data) {
        res.send({
            success: true,
            message: 'Berhasil ambil data!',
            data: data
        });
    } else {
        req.send({
            success: false,
            message: 'Gagal mengambil data!',
        });
    }
}

// menambahkan data 
const addDatapelanggan = async (req, res) => {
    let data = {            
        nama: req.body.nama,
        alamat: req.body.alamat,
        jenis_kelamin: req.body.jenis_kelamin,
        pekerjaan: req.body.pekerjaan
    }
    const result = await new Promise((resolve, reject) => {
        connection.query('INSERT INTO pelanggan SET ?', [data], function (error, rows) {
            if (rows) {
                resolve (true);
            } else  {
                reject (false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil x data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal menambahkan data!',
        })
    }
}

//mengubah data
const editDatapelanggan = async (req, res) => {
    let id = req.params.id;
    let dataedit = {
        nama: req.body.nama,
        alamat: req.body.alamat,
        jenis_kelamin: req.body.jenis_kelamin,
        pekerjaan: req.body.pekerjaan
    }

    const result = await new Promise ((resolve, reject) => {
        connection.query('UPDATE pelanggan SET ? WHERE id = ?;', [dataedit, id], function (error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil edit data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal edit data!',
        });
    }
}

// menghapus data
const deleteDatapelanggan = async (req, res) => {
    let id = req.params.id;

    const result = await new Promise((resolve, reject) => {
        connection.query('DELETE FROM pelanggan WHERE id = ?;', [id], function (error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil hapus data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal menghapus data!'
        });
    }
}

module.exports = {
    getDatapelanggan,
    addDatapelanggan,
    editDatapelanggan,
    deleteDatapelanggan
}