const obat = require('./controller-obat');
const supplier = require('./controller-supplier');
const pelanggan = require('./controller-pelanggan');
const karyawan = require('./controller-karyawan');
const faktur_supply = require('./controller-faktur_supply');
const faktur_penjualan = require('./controller-faktur_penjualan');

module.exports = {
    obat,
    supplier,
    pelanggan,
    karyawan,
    faktur_supply,
    faktur_penjualan
};