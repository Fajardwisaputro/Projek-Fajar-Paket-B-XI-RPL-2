const config = require('../configs/database');
const mysql = require('mysql');
const connection = mysql.createConnection(config);
connection.connect();

// menampilkan semua data
const getDatakaryawan = async (req, res) => {
    const data = await new Promise((resolve, reject) => {
        connection.query('SELECT * FROM karyawan', function (error, rows) {
            if (rows) {
                resolve(rows)
            } else {
                reject([]);
            }
        })
    });

    if (data) {
        res.send({
            success: true,
            message: 'Berhasil ambil data!',
            data: data
        });
    } else {
        req.send({
            success: false,
            message: 'Gagal mengambil data!',
        });
    }
}

// menambahkan data 
const addDatakaryawan = async (req, res) => {
    let data = {            
        nama: req.body.nama,
        alamat: req.body.alamat,
        kota: req.body.kota,
        status: req.body.status,
        no_telepon: req.body.no_telepon
    }
    const result = await new Promise((resolve, reject) => {
        connection.query('INSERT INTO karyawan SET ?', [data], function (error, rows) {
            if (rows) {
                resolve (true);
            } else  {
                reject (false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil x data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal menambahkan data!',
        })
    }
}

//mengubah data
const editDatakaryawan = async (req, res) => {
    let id = req.params.id;
    let dataedit = {
        nama: req.body.nama,
        alamat: req.body.alamat,
        kota: req.body.kota,
        status: req.body.status,
        no_telepon: req.body.no_telepon
    }

    const result = await new Promise ((resolve, reject) => {
        connection.query('UPDATE karyawan SET ? WHERE id = ?;', [dataedit, id], function (error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil edit data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal edit data!',
        });
    }
}

// menghapus data
const deleteDatakaryawan = async (req, res) => {
    let id = req.params.id;

    const result = await new Promise((resolve, reject) => {
        connection.query('DELETE FROM karyawan WHERE id = ?;', [id], function (error, rows) {
            if (rows) {
                resolve(true);
            } else {
                reject(false);
            }
        });
    });

    if (result) {
        res.send({
            success: true,
            message: 'Berhasil hapus data'
        });
    } else {
        res.send ({
            success: false,
            message: 'Gagal menghapus data!'
        });
    }
}

module.exports = {
    getDatakaryawan,
    addDatakaryawan,
    editDatakaryawan,
    deleteDatakaryawan
}